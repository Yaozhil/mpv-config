# mpv HDR 图形字幕色彩空间问题复现包

本复现包用于验证 `vo=gpu-next` 在 HDR 视频中合成 PGS 等图形字幕时的
色彩空间问题。

## 文件说明

- `hdr10-pgs-synthetic-sample.mkv`
  - 时长 15.015 秒
  - 1920×1080 HEVC Main 10
  - BT.2020 non-constant luminance / SMPTE ST 2084（PQ）
  - 纯黑合成视频背景
  - 一条 PGS 图形字幕轨
  - 无音频
- `output-upstream.txt`
  - `mpv v0.41.0-846-g99b4c12cc` 完整日志
- `output-patched.txt`
  - `mpv v0.41.0-847-g5157cc717` 完整日志
  - 启用了下游修复 `--image-subs-colorspace=auto`
- `sample-ffprobe.json`
  - 完整 FFprobe 流与容器信息
- `comparison-upstream-vs-fixed.jpg`
  - 真实 HDR 设备上的同帧对比
- `0001-vo_gpu_next-add-image-subtitle-colorspace-control.patch`
  - 定点核心补丁

## 复现命令

上游版本：

```console
mpv.com --no-config --vo=gpu-next --gpu-api=d3d11 --hwdec=no --audio=no --sid=1 --target-colorspace-hint=auto --target-colorspace-hint-mode=target --start=5.15 --length=2 --idle=no hdr10-pgs-synthetic-sample.mkv
```

动态 PGS 图形字幕约从 `00:05.130` 开始显示。

修复版本：

```console
mpv.com --no-config --vo=gpu-next --gpu-api=d3d11 --hwdec=no --audio=no --sid=1 --target-colorspace-hint=auto --target-colorspace-hint-mode=target --image-subs-colorspace=auto --start=5.15 --length=2 --idle=no hdr10-pgs-synthetic-sample.mkv
```

## SHA-256

```text
C76E56F9598F217A972D5B59760E7625268DE311C32A87C51F197C73C6E28688  hdr10-pgs-synthetic-sample.mkv
E517C5C5DE6024D5E7EB013DB136885368A03D0673F6400A6E20812EED1DF9CF  comparison-upstream-vs-fixed.jpg
3BE8B7E2190299220EF332B4238929FA43BDB3C541F1032995FB73141EFED82F  output-upstream.txt
01BFC7D33F5F80778208035ECFA30A1C2D0F022AFCA2452E8E1BC58EC6CB15A8  output-patched.txt
D1082CF8F3AF17EF96F2CE0F5098C987DF8910FE3AF1C8062B4BFA910E036765  0001-vo_gpu_next-add-image-subtitle-colorspace-control.patch
```

## 已落地的下游修复

项目：

https://github.com/Yaozhil/mpv-config

补丁：

https://github.com/Yaozhil/mpv-config/blob/codex/hdr-pgs-core-fix/patches/0001-vo_gpu_next-add-image-subtitle-colorspace-control.patch
